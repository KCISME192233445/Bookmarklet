in here you will find all my troll bookmarklets
