# lot-of-bookmarklet
 a ton of fun bookmarklets for school

i would like for this to be well known so pls star

and i will be adding bookmarks regularly so check this often

if you dont know how to use a bookmarklet this is how
when you see a bookmarklet you like all you got to do is click it copy the code 
bookmark the page. before you press done go to the url box and paste the code there

im not going to update this for a little bit but just wait a little while 
